# Stockroom frontend

React + Vite frontend for the Spring Boot product management API.

## Run locally

Start the backend on port 8080, then run:

```bash
npm install
npm run dev
```

Open <http://localhost:5173>. Vite proxies `/api` requests to `http://127.0.0.1:8080`, so backend CORS configuration is not needed during development.

## Backend contract

The UI matches `ProductController` in the `productManagementSystem` Spring project:

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/products` | List all products |
| GET | `/api/products/{id}` | Get one product |
| GET | `/api/products/search?name=abc` | Case-insensitive name search |
| POST | `/api/products` | Create a product |
| PUT | `/api/products/{id}` | Replace a product |
| PATCH | `/api/products/{id}` | Update changed fields |
| DELETE | `/api/products/{id}` | Delete a product |

Product payloads use this shape:

```json
{
  "name": "Laptop",
  "description": "HP",
  "price": 750.00,
  "quantity": 10,
  "status": "ACTIVE"
}
```

Status values are `ACTIVE` and `INACTIVE`. The controller has no status-filter endpoint, so status filtering is performed over the current API result in the browser. Dashboard statistics are calculated from the complete `/api/products` response.

For a deployment where the frontend and backend do not share an origin, set `VITE_API_BASE` to the complete products API URL and configure backend CORS accordingly.

Build with `npm run build`.
