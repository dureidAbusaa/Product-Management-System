import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { api } from './api';
import './style.css';

const EMPTY_PRODUCT = { name: '', description: '', price: '', quantity: '', status: 'ACTIVE' };
const PRODUCT_FIELDS = Object.keys(EMPTY_PRODUCT);
const STATUSES = ['ACTIVE', 'INACTIVE'];

function normalizeList(response) {
  if (Array.isArray(response)) return response;
  if (Array.isArray(response?.content)) return response.content;
  throw new Error('The product service returned an unexpected response.');
}

function formatNumber(value, fractionDigits = 2) {
  const number = Number(value);
  if (!Number.isFinite(number)) return '—';
  return number.toLocaleString('en-US', { minimumFractionDigits: fractionDigits, maximumFractionDigits: fractionDigits });
}

function toPayload(form) {
  const name = form.name.trim();
  const description = form.description.trim();
  const priceText = String(form.price).trim();
  const quantityText = String(form.quantity).trim();
  const price = Number(priceText);
  const quantity = Number(quantityText);
  if (!name || !description) throw new Error('Name and description are required.');
  if (!/^\d{1,10}(\.\d{1,2})?$/.test(priceText) || !Number.isFinite(price)) throw new Error('Price must be non-negative with up to 10 digits and 2 decimal places.');
  if (!/^\d+$/.test(quantityText) || !Number.isInteger(quantity) || quantity > 2147483647) throw new Error('Quantity must be a whole number from 0 to 2,147,483,647.');
  if (!STATUSES.includes(form.status)) throw new Error('Choose a valid product status.');
  return { name, description, price, quantity, status: form.status };
}

function getChangedFields(original, payload) {
  return Object.fromEntries(PRODUCT_FIELDS.filter((field) => {
    if (field === 'price' || field === 'quantity') return Number(payload[field]) !== Number(original[field]);
    return payload[field] !== original[field];
  }).map((field) => [field, payload[field]]));
}

function ProductDialog({ modal, form, setForm, busy, error, onClose, onSubmit }) {
  const title = { add: 'Add product', put: 'Edit product · PUT', patch: 'Partial update · PATCH', view: 'Product details', delete: 'Delete product' }[modal.mode];
  const readOnly = modal.mode === 'view' || busy;
  return (
    <div className="overlay" onClick={() => !busy && onClose()}>
      <section role="dialog" aria-modal="true" aria-labelledby="dialog-title" className="dialog" onClick={(event) => event.stopPropagation()}>
        <div className="panelhead"><h2 id="dialog-title">{title}</h2><button type="button" className="secondary" disabled={busy} onClick={onClose} aria-label="Close dialog">✕</button></div>
        <form onSubmit={onSubmit}>
          {modal.mode === 'delete' ? <p>Delete <b>{modal.product.name}</b>? This cannot be undone.</p> : PRODUCT_FIELDS.map((field) => (
            <label key={field}>{field}
              {field === 'status' ? (
                <select disabled={readOnly} value={form[field]} onChange={(event) => setForm({ ...form, [field]: event.target.value })}>
                  {STATUSES.map((status) => <option key={status}>{status}</option>)}
                </select>
              ) : (
                <input required readOnly={readOnly} maxLength={field === 'name' || field === 'description' ? 255 : undefined}
                  type={field === 'price' || field === 'quantity' ? 'number' : 'text'} min={field === 'price' || field === 'quantity' ? 0 : undefined}
                  max={field === 'quantity' ? 2147483647 : undefined} step={field === 'price' ? '0.01' : field === 'quantity' ? '1' : undefined}
                  value={form[field]} onChange={(event) => setForm({ ...form, [field]: event.target.value })} />
              )}
            </label>
          ))}
          {modal.mode === 'patch' && <small>Only fields that differ from the saved product are sent.</small>}
          {error && <div role="alert" className="error form-error">{error}</div>}
          <div className="dialogactions">
            <button type="button" className="secondary" disabled={busy} onClick={onClose}>{modal.mode === 'view' ? 'Close' : 'Cancel'}</button>
            {modal.mode !== 'view' && <button className={modal.mode === 'delete' ? 'delete primary' : 'primary'} disabled={busy}>{busy ? 'Working…' : modal.mode === 'delete' ? 'Delete product' : 'Save product'}</button>}
          </div>
        </form>
      </section>
    </div>
  );
}

function App() {
  const [catalog, setCatalog] = useState([]);
  const [products, setProducts] = useState([]);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('ALL');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState(EMPTY_PRODUCT);
  const [busy, setBusy] = useState(false);
  const [revision, setRevision] = useState(0);
  const [dark, setDark] = useState(() => localStorage.getItem('stockroom-theme') === 'dark');
  const [formError, setFormError] = useState('');

  useEffect(() => { localStorage.setItem('stockroom-theme', dark ? 'dark' : 'light'); }, [dark]);
  useEffect(() => {
    const controller = new AbortController();
    const searchTerm = query.trim();
    const timeout = window.setTimeout(async () => {
      setLoading(true); setError('');
      try {
        const [allResponse, searchResponse] = await Promise.all([api.list(controller.signal), searchTerm ? api.search(searchTerm, controller.signal) : Promise.resolve(null)]);
        const allProducts = normalizeList(allResponse);
        setCatalog(allProducts);
        setProducts(searchTerm ? normalizeList(searchResponse) : allProducts);
      } catch (requestError) {
        if (requestError.name !== 'AbortError') { setError(requestError.message); setCatalog([]); setProducts([]); }
      } finally { if (!controller.signal.aborted) setLoading(false); }
    }, searchTerm ? 300 : 0);
    return () => { window.clearTimeout(timeout); controller.abort(); };
  }, [query, revision]);
  useEffect(() => {
    if (!notice) return undefined;
    const timeout = window.setTimeout(() => setNotice(''), 4000);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  const visibleProducts = useMemo(() => products.filter((product) => status === 'ALL' || product.status === status), [products, status]);
  const stats = useMemo(() => ({
    total: catalog.length,
    active: catalog.filter((product) => product.status === 'ACTIVE').length,
    units: catalog.reduce((total, product) => total + Number(product.quantity || 0), 0),
    value: catalog.reduce((total, product) => total + Number(product.price || 0) * Number(product.quantity || 0), 0),
  }), [catalog]);

  function refreshProducts() { setRevision((value) => value + 1); }
  function openDialog(mode, product) {
    setFormError('');
    setForm(product ? Object.fromEntries(PRODUCT_FIELDS.map((field) => [field, String(product[field] ?? '')])) : { ...EMPTY_PRODUCT });
    setModal({ mode, product });
  }
  async function openProduct(mode, product) {
    setBusy(true); setError('');
    try {
      const latestProduct = await api.get(product.id);
      if (!latestProduct) throw new Error('The requested product was not found.');
      openDialog(mode, latestProduct);
    } catch (requestError) { setError(requestError.message); } finally { setBusy(false); }
  }
  async function submitProduct(event) {
    event.preventDefault(); setBusy(true); setFormError('');
    try {
      if (modal.mode === 'delete') { await api.remove(modal.product.id); setNotice('Product deleted successfully.'); }
      else {
        const payload = toPayload(form);
        if (modal.mode === 'add') { await api.create(payload); setNotice('Product created successfully.'); }
        else if (modal.mode === 'put') { await api.replace(modal.product.id, payload); setNotice('Product replaced successfully.'); }
        else {
          const changes = getChangedFields(modal.product, payload);
          if (!Object.keys(changes).length) throw new Error('No changes to save.');
          await api.patch(modal.product.id, changes); setNotice('Product updated successfully.');
        }
      }
      setModal(null); refreshProducts();
    } catch (requestError) { setFormError(requestError.message); } finally { setBusy(false); }
  }

  const statCards = [['Total products', stats.total, '▦'], ['Active products', stats.active, '◉'], ['Units in stock', stats.units.toLocaleString('en-US'), '▤'], ['Inventory value', formatNumber(stats.value), '◇']];
  return (
    <div className={dark ? 'app dark' : 'app'}>
      <aside><div className="brand"><span className="logo">▦</span> Stockroom<span className="dot">.</span></div><small>WORKSPACE</small><div className="nav">▤ &nbsp; Products</div><div className="sidebottom">Inventory workspace<br /><small>PRODUCT MANAGEMENT</small></div></aside>
      <main>
        <header><span>Workspace / <b>Products</b></span><button className="secondary" onClick={() => setDark((value) => !value)}>{dark ? '☀ Light' : '☾ Dark'}</button></header>
        <section className="intro"><div><div className="eyebrow">INVENTORY MANAGEMENT</div><h1>Products</h1><p>Manage your catalog, stock levels and product availability.</p></div><button className="primary" onClick={() => openDialog('add')}>＋ Add product</button></section>
        <div className="stats">{statCards.map(([label, value, icon]) => <article key={label}><span className="statIcon">{icon}</span><p>{label}</p><strong>{loading || error ? '—' : value}</strong></article>)}</div>
        <p className="scope">Statistics reflect all products currently stored by the API.</p>
        <section className="panel">
          <div className="panelhead"><div><h2>Product catalog</h2><p>Browse and manage your inventory.</p></div><button className="secondary" disabled={loading} onClick={refreshProducts}>↻ Refresh</button></div>
          <div className="toolbar"><input aria-label="Search products by name" placeholder="⌕  Search by name…" value={query} onChange={(event) => setQuery(event.target.value)} /><select aria-label="Filter products by status" value={status} onChange={(event) => setStatus(event.target.value)}><option value="ALL">All statuses</option>{STATUSES.map((productStatus) => <option key={productStatus}>{productStatus}</option>)}</select></div>
          {error && <div role="alert" className="error">{error} Check that the backend is running on port 8080.</div>}
          {loading ? <div className="empty" aria-live="polite">Loading products…</div> : !error && (
            <div className="tablewrap"><table><thead><tr>{['Product', 'ID', 'Price', 'Stock', 'Status', 'Actions'].map((label) => <th key={label}>{label}</th>)}</tr></thead><tbody>{visibleProducts.map((product) => (
              <tr key={product.id}><td><div className="product"><span className="avatar">{product.name?.slice(0, 2).toUpperCase()}</span><div><b>{product.name}</b><small>{product.description}</small></div></div></td><td>#{product.id}</td><td>{formatNumber(product.price)}</td><td>{Number(product.quantity).toLocaleString('en-US')}</td><td><span className={`pill ${product.status}`}>{product.status}</span></td><td><div className="actions">{[['view', 'View'], ['put', 'Edit'], ['patch', 'Patch']].map(([mode, label]) => <button disabled={busy} key={mode} onClick={() => openProduct(mode, product)}>{label}</button>)}<button disabled={busy} className="danger" onClick={() => openDialog('delete', product)}>Delete</button></div></td></tr>
            ))}</tbody></table>{!visibleProducts.length && <div className="empty">No products match the current search and status filter.</div>}</div>
          )}
          <footer>{visibleProducts.length} {visibleProducts.length === 1 ? 'product' : 'products'} shown</footer>
        </section>
      </main>
      {notice && <div role="status" className="toast">✓ {notice}</div>}
      {modal && <ProductDialog modal={modal} form={form} setForm={setForm} busy={busy} error={formError} onClose={() => setModal(null)} onSubmit={submitProduct} />}
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
