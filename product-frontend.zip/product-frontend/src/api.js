const baseUrl = (import.meta.env.VITE_API_BASE || '/api/products').replace(/\/$/, '');

async function request(path = '', { method = 'GET', body, signal } = {}) {
  let response;
  try {
    response = await fetch(`${baseUrl}${path}`, {
      method,
      signal,
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new Error('Unable to reach the product service.');
  }

  const text = await response.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch { data = text; }
  }
  if (!response.ok) {
    const backendMessage = data?.detail || data?.message || data?.error;
    throw new Error(backendMessage || `Product service returned HTTP ${response.status}.`);
  }
  return data;
}

export const api = {
  list: (signal) => request('', { signal }),
  search: (name, signal) => request(`/search?name=${encodeURIComponent(name)}`, { signal }),
  get: (id, signal) => request(`/${encodeURIComponent(id)}`, { signal }),
  create: (product) => request('', { method: 'POST', body: product }),
  replace: (id, product) => request(`/${encodeURIComponent(id)}`, { method: 'PUT', body: product }),
  patch: (id, changes) => request(`/${encodeURIComponent(id)}`, { method: 'PATCH', body: changes }),
  remove: (id) => request(`/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};
